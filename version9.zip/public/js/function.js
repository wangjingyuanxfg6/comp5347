
google.charts.load('current', {packages: ['corechart']})
var revisionLimit = 2;

function isoToNormal(isoString){
    return new Date(isoString).toLocaleString()
}

function colldiv(divid){
    var dis = document.getElementById(divid).style.display;
    if(dis=="" || dis=="block"){
        document.getElementById(divid).style.display="none";
    }else{
        document.getElementById(divid).style.display="";
    }
}
function revLimitBtn(){
    var revisionLimit = $("#revLimitText").val();
    if(revisionLimit.trim()==""){
        alert("Input nothing!");
        return false;
    }
    revisionLimit = parseInt($("#revLimitText").val());
    //highest
    var options = {sortDirection:-1,displayLimit:revisionLimit}
    $.get('analytic/queryExtRev',options, function(data){
        $("#highestRev").empty(); //empty current content
        $("#highestRev").append(`
        <table class="table"> <thead><tr><th>Title</th><th> Revisions</th></tr></thead><tbody>
      `)//create table head
        for(var i=0;i<data.length;i++){
            $("#highestRev tbody").append(` 
        <tr> <td>${data[i]._id.title}</td>  <td>${data[i].count}</td></tr>`);
        }
        $("#highestRev").append(`</tbody></table>`)
    })

    options = {sortDirection:1,displayLimit:revisionLimit}
    $.get('analytic/queryExtRev',options, function(data){
        $("#lowestRev").empty(); //empty current content
        $("#lowestRev").append(`<table class="table"><thead><tr><th>Title</th><th> Revisions</th></tr> </thead>
        <tbody>
      `)
        for(var i=0;i<data.length;i++){
            $("#lowestRev tbody").append(` 
        <tr> <td>${data[i]._id.title}</td>  <td>${data[i].count}</td> </tr>`);
        }
        $("#lowestRev").append(`</tbody></table>
      `)
    })
}
function titleListBtn(){
    var topUsers =[];
    event.preventDefault();
    var articleName = $("#titleList")[0].value;
    var yearFrom =$("#yearFromList")[0].value
    var yearTo =$("#yearToList")[0].value
    $.get('analytic/updateArticle', {"title":articleName},function(data){
        var ddc ="";
        if (data.updatedLength>0){
            ddc=`Update Download Count:${data.updatedLength}`
        }else if(data.updatedLength==-1){
            ddc = "Fresh revisions. No request sent to Wiki."
        }else{
            ddc = "No update available on Wiki"
        }
        document.getElementById("dataUpdateDisplay").innerHTML=ddc;
        $.get('analytic/getArticleTopUsers', {"title":articleName, "yearfrom":yearFrom,"yearto":yearTo}, function(data){
            if(data==""){//no data
                alert("During this period, there is no revision history.");
            }
            $("#articleTopUsers").empty();
            $("#articleTopUsers").append(`
        <table class="table"><thead> <tr><th scope="col">User Name</th><th scope="col">Revisions</th>
            </tr></thead><tbody>`)

            for (var i=0;i<data.length;i++){
                topUsers.push(data[i]._id.user);
                $("#articleTopUsers tbody").append(` 
            <tr>  <td>${data[i]._id.user}</td> <td>${data[i].count}</td></tr>`)
            }

            $("#userList").empty();
            for (var i in topUsers){
               // ddc=`<option value="${topUsers[i]}">${topUsers[i]}  </option>`
                ddc=`<input type="checkbox" class="checkbox" value="${topUsers[i]}">${topUsers[i]}`
                $("#userList").append(ddc)
            }
        })
    })
}
function userNameButton(){
    var userName = $("#userNameText")[0].value;
    if(userName.trim()==""){
        alert("Input nothing!");
        return false;
    }
    $.get('analytic/findUserType', {"user":userName}, function(data){
        $("#usertypedisplay").empty();
        if(data==""){
            alert("User name do not exist.")
            return false;
        }

        for(var i=0;i<data.length;i++) {
            $("#usertypedisplay").append("usertype is "+data[i].usertype)
        }
    })
}
function authorNameButton(){
    authorName = $("#createNameText")[0].value;
    if(authorName.trim()==""){
        alert("Input nothing!");
        return false;
    }
    $.get('analytic/findUserAriticle', {"user":authorName}, function(data){
        $("#articleUserDisplay").empty();

        $("#articleUserDisplay").append(`
        <table class="table"><thead> <tr><th scope="col">User</th><th scope="col">Article</th><th scope="col">Revisions</th><th scope="col"></th>
            </tr></thead><tbody>`)
        $.each(data, (index,row)=>{
            $("#articleUserDisplay tbody").append(` 
            <tr>  <td>${row._id.user}</td> <td>${row._id.title}</td><td>${row.count}</td><td><button type="button" class="btn" onclick="colldiv('row${index}')" >Show Time</button><div id="row${index}" style="display: none" ></div></td></tr>`)
            row.timeStamps.sort();

            for (var i=0;i<row.timeStamps.length;i++){
                timestamp = isoToNormal(row.timeStamps[i]);
                $("#row"+index).append(`<div class="row articleUserDisInner"> <div class="col-sm-1">${i+1}</div><div class="col-sm-10">${timestamp}</div></div>`)
            }
        })
        $("#articleUserDisplay").append(`</tbody></table>`)
    })
}
$(function() {
  // utility functions
  function getChartOptions(title,type){
    var array ={'title':title}
    if(type == 'mini'){
        //,'backgroundColor': { fill:'transparent' },'legend.textStyle':{color: 'white'}
        array ={'title':title,'width':465,'height':232 }
    }else if(type == 'max'){
        array = { 'title':title, 'width':1040,'height':207}
    }
    return array
  }


  $("#overview_id").click(function(event){
    event.preventDefault();
      document.getElementById("individual_section").style.display="none"
      document.getElementById("article_section").style.display="none"
      document.getElementById("overview_section").style.display="block"

      document.getElementById("overview_id").classList.add("active")
      document.getElementById("article_id").classList.remove("active")
      document.getElementById("individual_id").classList.remove("active")
  })

  $("#individual_id").click(function(event){
    event.preventDefault();
      document.getElementById("individual_section").style.display="block"
      document.getElementById("overview_section").style.display="none"
      document.getElementById("article_section").style.display="none"

      document.getElementById("individual_id").classList.add("active")
      document.getElementById("overview_id").classList.remove("active")
      document.getElementById("article_id").classList.remove("active")
  })

  $("#article_id").click(function(event){
    event.preventDefault();
      document.getElementById("article_section").style.display="block"
      document.getElementById("overview_section").style.display="none"
      document.getElementById("individual_section").style.display="none"

      document.getElementById("article_id").classList.add("active")
      document.getElementById("overview_id").classList.remove("active")
      document.getElementById("individual_id").classList.remove("active")
  })

    function cChart(data, selector){
        graphData = new google.visualization.DataTable();
        graphData.addColumn('string', 'Year');
        graphData.addColumn('number', 'admin');
        graphData.addColumn('number', 'Bot');
        graphData.addColumn('number', 'Anonymous');
        graphData.addColumn('number', 'Registered User');
        for(var i=0;i<data.length;i++){
            graphData.addRow([data[i]._id.year,data[i].admin,data[i].bot,data[i].anonymous,data[i].registered]);
        }
        var options = getChartOptions("Distribution of User Types by Year","max");
        var chart = new google.visualization.ColumnChart($(selector)[0]);
        chart.draw(graphData, options);
        if(selector=="#individualColChart"){
            document.getElementById("individualAdminChart").style.display="none"
            document.getElementById("individualChart").style.display="none"
            document.getElementById("individualConChart").style.display="none"
            document.getElementById("individualColChart").style.display=""
        }else{
            document.getElementById("overviewAdminChart").style.display="none"
            document.getElementById("overviewChart").style.display="none"
            document.getElementById("overviewColChart").style.display=""
        }

        //document.getElementById("individualAdminChart").style.display="none"
    }



  




    function drawAdminPie(data,selector){
        // Revision number distribution by year and by user
        graphData = new google.visualization.DataTable();
        graphData.addColumn('string', 'User');
        graphData.addColumn('number', 'Number');
        for(var i=0;i<data.length;i++){
            graphData.addRow([data[i]._id.admintype, data[i].count]);
        }

        var options = getChartOptions("Distribution by Admin User Type","mini")
        var chart = new google.visualization.PieChart($(selector)[0]);
        chart.draw(graphData, options);
        if(selector=="#individualAdminChart"){
            document.getElementById("individualAdminChart").style.display=""
        }else{
            document.getElementById("overviewAdminChart").style.display=""
        }

    }


  $("#usertypeDisPie").click(function(event){
    event.preventDefault();
    $.get('analytic/queryUsertypeDis', function(data){
        drawPie(data, "#overviewChart");
      })
  })
    function drawPie(data,selector){
        // Revision number distribution by year and by user
        graphData = new google.visualization.DataTable();
        graphData.addColumn('string', 'User');
        graphData.addColumn('number', 'Number');
        for(var i=0;i<data.length;i++){
            graphData.addRow([data[i]._id.usertype, data[i].count]);
        }
        var options = getChartOptions("Distribution by User Type","mini")
        var chart = new google.visualization.PieChart($(selector)[0]);
        google.visualization.events.addListener(chart,'select',function(e){
            var selectedItem=chart.getSelection()[0];
            if(selectedItem){
                var topping =graphData.getValue(selectedItem.row,0);
                if(topping=='admin'){
                    $.get('analytic/queryAdminUsertypeDis', function(data){
                        if(selector=="#overviewChart"){
                            drawAdminPie(data, "#overviewAdminChart");
                        }else{
                            drawAdminPie(data, "#individualAdminChart");
                        }
                    })
                }
            }
        });
        if(selector=="#overviewChart"){
            document.getElementById("overviewColChart").style.display="none";
            document.getElementById("overviewChart").style.display="";
        }else{
            document.getElementById("individualColChart").style.display="none";
            document.getElementById("individualConChart").style.display="none";
            document.getElementById("individualChart").style.display="";
        }

        chart.draw(graphData, options);
    }

  var yearData = ['2001','2002','2003','2004','2005','2006','2007','2008','2009','2010','2011','2012','2013','2014','2015','2016','2017','2018','2019'];
    yearData.forEach(function(item, index){
        display_content="<option value='"+item+"'>"+item+"</option>"
        $("#yearFromList").append(display_content)
        $("#yearToList").append(display_content)
    });

    var articleName = $("#titleList")[0].value;
    var yearFrom =$("#yearFromList")[0].value
    var yearTo =$("#yearToList")[0].value


    $("#yearDisCol").click(function(event){
        event.preventDefault();
        $.get('analytic/queryUsertypeDisByYear', function(data){
            cChart(data, "#overviewColChart");
        })
    })
  $("#articleDisYearCol").click(function(event){
    event.preventDefault();
      var articleName = $("#titleList")[0].value;
      var yearFrom =$("#yearFromList")[0].value
      var yearTo =$("#yearToList")[0].value
    $.get('analytic/queryArticleDisYear',{"title":articleName, "yearfrom":yearFrom,"yearto":yearTo}, function(data){
      cChart(data, "#individualColChart");
    })
  })    
  

  
  $("#articleDisByUserCol").click(function(event){
      event.preventDefault();
      var userName = [];
      $.each($('input:checkbox:checked'),function(){
          userName.push($(this).val())
      });
      var userNameAll = [];
      $.each($('input:checkbox'),function(){
          userNameAll.push($(this).val())
      });
      //var userName =$("#userList")[0].value
      var articleName = $("#titleList")[0].value;
      var yearFrom =$("#yearFromList")[0].value
      var yearTo =$("#yearToList")[0].value

      var options = getChartOptions("Article Revision Number Distribution by User by Year","max");
      $.get('analytic/queryArticleDisByUser',{"title":articleName, "user":userName, "yearfrom":yearFrom,"yearto":yearTo}, function(data){
        var graphData = new google.visualization.DataTable();
        graphData.addColumn('string', 'Year');
        for (var i=0;i<userNameAll.length;i++) {
            graphData.addColumn('number', userName[i]);
        }


          for (var i=0;i<data.length;i++){
              graphData.addRow([data[i]._id.year,data[i].user1,data[i].user2,data[i].user3,data[i].user4,data[i].user5]);
          }

        var chart = new google.visualization.ColumnChart($("#individualConChart")[0]);
        chart.draw(graphData, options);
          document.getElementById("individualAdminChart").style.display="none"
          document.getElementById("individualChart").style.display="none"
          document.getElementById("individualConChart").style.display=""
          document.getElementById("individualColChart").style.display="none"
  })})
    $.get('analytic/getAllTitles', function(data){
        $("#titleList").append(`<option value="">请选择</option>`)

        for (var i=0;i<data.length;i++){
            display_content=`<option value="${data[i]._id.title}">${data[i]._id.title}  (${data[i].count})</option>`
            $("#titleList").append(display_content)
        }
    })





    $("#articleDisUsertypePie").click(function(event){
        event.preventDefault();
        var articleName = $("#titleList")[0].value;
        var yearFrom =$("#yearFromList")[0].value
        var yearTo =$("#yearToList")[0].value
        $.get('analytic/queryArticleDisUsertype',{"title":articleName, "yearfrom":yearFrom,"yearto":yearTo}, function(data){
            drawPie(data, "#individualChart");
        })})

    initAllData()//get all data at first
    function initAllData(){
        //highest
        var options = {sortDirection:-1,displayLimit:2}
        $.get('analytic/queryExtRev',options, function(data){
            $("#highestRev").empty(); //empty current content
            $("#highestRev").append(`
        <table class="table">
          <thead><tr><th>Title</th>
              <th> Revisions</th></tr></thead>
        <tbody>
      `)//create table head
            for(var i=0;i<data.length;i++){
                $("#highestRev tbody").append(` 
        <tr>  
          <td>${data[i]._id.title}</td>  <td>${data[i].count}</td>
        </tr>`);
            }
            $("#highestRev").append(`
        </tbody>
      </table>
      `)
        })

        //lowest
        options = {sortDirection:1,displayLimit:2}
        $.get('analytic/queryExtRev',options, function(data){
            $("#lowestRev").empty(); //empty current content
            $("#lowestRev").append(`
        <table class="table">
          <thead><tr> <th >Title</th><th > Revisions</th>
            </tr></thead> <tbody>
      `)
            for(var i=0;i<data.length;i++){
                $("#lowestRev tbody").append(` 
        <tr> <td>${data[i]._id.title}</td>  <td>${data[i].count}</td> </tr>`);
            }
            $("#lowestRev").append(`</tbody></table>
      `)
        })
        //largest
        options = {sortDirection:-1}
        $.get('analytic/queryExtRegisterUsersGroup',options, function(data){
            $("#larGroupUser").empty();
            $("#larGroupUser").append(`<table class="table"><thead><tr><th >Title</th><th scope="col"> Revisions</th></tr></thead>
        <tbody>`)
            var prevCount = data[0].count;
            for(var i=0;i<data.length;i++) {
                if (data[i].count == prevCount) {
                    $("#larGroupUser tbody").append(`  <tr>  <td>${data[i]._id.title}</td>  <td>${data[i].count}</td></tr>`);
                }
            }
                $("#larGroupUser").append(`</tbody></table>`)
        })

        //smallest
        //render largest/smallest group of registered users
        options = {sortDirection:1}
        $.get('analytic/queryExtRegisterUsersGroup',options, function(data){
            $("#samllGroupUser").empty(); //empty current content
            $("#samllGroupUser").append(`
        <table class="table">
          <thead><tr><th >Title</th><th> Revisions</th>
            </tr></thead><tbody>
      `)
            var prevCount = data[0].count;
            for(var i=0;i<data.length;i++){
                if (data[i].count==prevCount){
                    $("#samllGroupUser tbody").append(` <tr>   <td>${data[i]._id.title}</td>  <td>${data[i].count}</td>
            </tr>`); }
            }
            $("#samllGroupUser").append(`</tbody></table>`)
        })

        //longest
        options = {sortDirection:1,displayLimit:2}
        $.get('analytic/queryExtHistory',options, function(data){
            $("#lHistory").empty(); //empty current content
            $("#lHistory").append(`
        <table class="table"><thead><tr><th >Title</th><th >Creation Time</th></tr>
          </thead><tbody>
      `)
            for(var i=0;i<data.length;i++){
                data[i].firstEditTime = isoToNormal(data[i].firstEditTime);
                $("#lHistory tbody").append(` <tr>   <td>${data[i]._id.title}</td>  <td>${data[i].firstEditTime}</td></tr>`);
            }
            $("#lHistory").append(`</tbody> </table>
      `)
        })

        //shortest
        options = {sortDirection:-1,displayLimit:1}
        $.get('analytic/queryExtHistory',options, function(data){
            $("#sHistory").empty(); //empty current content
            $("#sHistory").append(`<table class="table"> <thead><tr>
              <th>Title</th><th >Creation Time</th></tr> </thead> <tbody>
      `)
            for(var i=0;i<data.length;i++){
                data[i].firstEditTime = isoToNormal(data[i].firstEditTime);
                $("#sHistory tbody").append(` <tr>  <td>${data[i]._id.title}</td>  <td>${data[i].firstEditTime}</td></tr>`);
            }
            $("#sHistory").append(`</tbody></table>
      `)
        })
    }


});