$(function() {
    $('.popup-with-zoom-anim').magnificPopup({
        type: 'inline',
        fixedContentPos: false,
        fixedBgPos: true,
        overflowY: 'auto',
        closeBtnInside: true,
        preloader: false,
        midClick: true,
        removalDelay: 300,
        mainClass: 'my-mfp-zoom-in'
    });

    $("#registerForm").click(function(event){

        var firstname = document.getElementById("firstname").value;
        if(firstname.trim()==""){
            alert("firstname Input nothing!");
            document.getElementById("firstname").focus();
            return false;
        }
        var lastname = document.getElementById("lastname").value;
        if(lastname.trim()==""){
            alert("lastname Input nothing!");
            document.getElementById("lastname").focus();
            return false;
        }
        var emailaddress = document.getElementById("emailaddress").value;
        if(emailaddress.trim()==""){
            alert("Email Input nothing!");
            document.getElementById("emailaddress").focus();
            return false;
        }
        var username = document.getElementById("username").value;
        if(username.trim()==""){
            alert("username Input nothing!");
            document.getElementById("username").focus();
            return false;
        }
        var password = document.getElementById("password").value;
        if(password.trim()==""){
            alert("password Input nothing!");
            document.getElementById("password").focus();
            return false;
        }
        var data = {"lastname":lastname,"firstname":firstname,"emailaddress":emailaddress,"username":username,"password":password};
      $.ajax({
        type: 'post',
        url: '/register',
        data: data,
        success: function(res){
            if(res.registerStatus == false){
              document.getElementById("registerStatus").style.color="red"
                document.getElementById("registerStatus").innerText="Email address has already existed, please choose another one."
            }else if(res.registerStatus == true){
                document.getElementById("registerStatus").style.color="green"
                document.getElementById("registerStatus").innerText="Register successfully,please login in."
            }
        },
          error: function (res) {
              console.log("server is busy,please try it again")
          }
      })
    });
    $("#loginForm").click(function(event){
        var emailaddress = document.getElementById("lemailaddress").value;
        if(emailaddress.trim()==""){
            alert("Email Input nothing!");
            document.getElementById("lemailaddress").focus();
            return false;
        }
        var password = document.getElementById("lpassword").value;
        if(password.trim()==""){
            alert("Password Input nothing!");
            document.getElementById("lpassword").focus()
            return false;
        }
        var data = {"emailaddress":emailaddress,"password":password};
        $.ajax({
            type: 'post',
            url: '/login',
            data: data,
            success: function(res){
                if(res.timeStatus == false){//if login fail
                    document.getElementById("timeStatus").style.color="red"
                    document.getElementById("timeStatus").innerText="Email address does not match password. Try again or Register"
                }else if(res.timeStatus == true){
                    //window.location.href= "/analytic";
                    window.parent.location.href = "/analytic";
                }
            },
            error: function (res) {
                console.log("server is busy,please try it again")
            }
        })
    });
});