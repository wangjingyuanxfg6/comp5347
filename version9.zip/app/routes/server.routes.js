var express = require('express')
var controller = require('../controllers/server.controller.js')
var router = express.Router()
var passport = require('passport');

router.post('/login', controller.loginUser);
router.get('/', controller.toMain);
router.get('/main', controller.toMain);
router.get('/analytic/findUserAriticle', controller.findUserAriticle);
router.get('/analytic/findUserType', controller.findUserType);
router.get('/analytic', controller.toAnalytic);
router.get('/analytic/getAllTitles', controller.getAllTitles);
router.get('/analytic/getArticleTopUsers', controller.getArticleTopUsers);
router.get('/analytic/queryAdminUsertypeDis', controller.queryAdminUsertypeDis);
router.get('/analytic/queryExtRev', controller.queryExtRev);
router.get('/analytic/queryExtHistory', controller.queryExtHistory);
router.get('/analytic/queryArticleDisUsertype', controller.queryArticleDisUsertype);
router.get('/analytic/queryArticleDisByUser', controller.queryArticleDisByUser);
router.get('/analytic/queryExtRegisterUsersGroup', controller.queryExtRegisterUsersGroup);
router.get('/analytic/updateArticle', controller.updateArticle);
router.get('/analytic/queryUsertypeDis', controller.queryUsertypeDis);
router.post('/register', controller.registerUser);
router.get('/logout', controller.logout);
router.get('/analytic/queryUsertypeDisByYear', controller.queryUsertypeDisByYear);
router.get('/analytic/queryArticleDisYear', controller.queryArticleDisYear);







module.exports = router;
