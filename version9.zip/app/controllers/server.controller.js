var model = require('../models/model.js');
var passport = require('passport');

function toMain(req,res){
    res.sendfile("app/views/login.html")
}
function toAnalytic(req,res){
  if(req.session.timeStatus==true){ //if authenticated
    res.sendfile("app/views/function.html")
  }else{
      res.sendfile("app/views/login.html")
  }
}

function queryExtRev(req,res){
    model.revision.queryExtRev(req.query).then(function (result) {
            res.send(result)
        }).catch(function (err) {
        console.log(err.message)
    })
}
function queryExtRegisterUsersGroup(req,res){
    model.revision.queryExtRegisterUsersGroup(req.query).then(function (result) {
        res.send(result)
    }).catch(function (err) {
        console.log(err.message)
    })
}
function queryExtHistory(req,res){

    model.revision.queryExtHistory(req.query).then(function (result) {
        res.send(result)
    }).catch(function (err) {
        console.log(err.message)
    })
}
function queryUsertypeDisByYear(req,res){

    model.revision.queryUsertypeDisByYear(req.query).then(function (result) {
        res.send(result)
    }).catch(function (err) {
        console.log(err.message)
    })
}
function registerUser(req,res){
    var registerStatus = false;
    model.user.registerUser(req.body).then(()=>{
        console.log("Successfully");
        registerStatus = true;
    }).catch(err=>{
        console.log(err)
    }).then(()=>{
        res.send({registerStatus:registerStatus})
    })
}

function queryArticleDisYear(req,res){

    model.revision.queryArticleDisYear(req.query).then(function (result) {
        res.send(result)
    }).catch(function (err) {
        console.log(err.message)
    })
}
function updateArticle(req,res){
    var title = req.query.title;

    model.revision.getAriticleLastDate(title).then(function (result) {
        var currDate = new Date();//UTC
        var lastDate = new Date(result[0].date);
        var diff = Math.floor((currDate-lastDate)/(1000 * 60 * 60 * 24));
        if (diff>1){
            model.revision.updateArticle(title, lastDate, function(err, updatedLength){
                res.send({updatedLength:updatedLength})
            })
        }else{
            res.send({updatedLength:-1})
        }
    }).catch(function (err) {
        console.log(err.message)
    })
}

function queryUsertypeDis(req,res){

    model.revision.queryUsertypeDis(req.query).then(function (result) {
        res.send(result)
    }).catch(function (err) {
        console.log(err.message)
    })
}

function loginUser(req,res){
    var timeStatus = false;

    model.user.findUser(req.body).then(function (result) {
        if(result.length>0){
            console.log("Successfully");
            timeStatus = true;
        }else{
            timeStatus = false;
        }
        req.session.timeStatus = timeStatus;
        res.send({timeStatus:timeStatus})
    }).catch(function (err) {
        res.send({timeStatus:timeStatus})
    })
}

function queryArticleDisUsertype(req,res){

    model.revision.queryArticleDisUsertype(req.query).then(function (result) {
        res.send(result)
    }).catch(function (err) {
        console.log(err.message)
    })
}

function findUserAriticle(req,res){

    model.revision.findUserAriticle(req.query).then(function (result) {
        res.send(result)
    }).catch(function (err) {
        console.log(err.message)
    })
}
function findUserType(req,res){

    model.revision.findUserType(req.query).then(function (result) {
        res.send(result)
    }).catch(function (err) {
        console.log(err.message)
    })
}
function queryArticleDisByUser(req,res){

    model.revision.queryArticleDisByUser(req.query).then(function (result) {
        res.send(result)
    }).catch(function (err) {
        console.log(err.message)
    })
}

function getArticleTopUsers(req,res){

    model.revision.getArticleTopUsers(req.query).then(function (result) {
        res.send(result)
    }).catch(function (err) {
        console.log(err.message)
    })
}
function logout(req,res){
    req.session.timeStatus = false
    res.sendfile("app/views/login.html")
}
function getAllTitles(req,res){

    model.revision.getAllTitles().then(function (result) {
        res.send(result)
    }).catch(function (err) {
        console.log(err.message)
    })
}
function queryAdminUsertypeDis(req,res){

    model.revision.queryAdminUsertypeDis(req.query).then(function (result) {
        res.send(result)
    }).catch(function (err) {
        console.log(err.message)
    })
}
// exports
module.exports = {toMain, toAnalytic, registerUser, loginUser, queryExtRev,queryExtRegisterUsersGroup, queryExtHistory, queryUsertypeDis,queryAdminUsertypeDis, queryUsertypeDisByYear,getAllTitles, getArticleTopUsers,queryArticleDisYear, queryArticleDisUsertype, queryArticleDisByUser, findUserAriticle,findUserType, updateArticle,logout}















