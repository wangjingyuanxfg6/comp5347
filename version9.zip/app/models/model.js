var mongoose = require('./db.js');
var fs = require('fs');
var request = require('request');
var querystring = require("querystring");

var revCollection = new mongoose.Schema(
  {
    user: String,
    anon: String,
    timestamp: String,
    title: String, 
    usertype:String,
    admintype:String,
  },
  {
    versionKey: false
  } 
);


revCollection.statics.queryExtRegisterUsersGroup = function(options){
    var pip = [];
  pip = [
    { $match:{usertype:"registered"} },
    {
      $group : {
        _id  : {title:"$title"},
        count: { $sum:1 }
      }
    },
    { $sort:{ count:parseInt(options.sortDirection) } },
    { $limit: 50 }
   ]
  return this.aggregate(pip).exec()
}

revCollection.statics.queryExtHistory = function(options){
    var per = [];
   per = [
    {
      $group : {
        _id : {title:"$title"},
        firstEditTime: {$min:"$timestamp"},       
      }
    },
    { $sort:{ firstEditTime:parseInt(options.sortDirection) } },
    { $limit: parseInt(options.displayLimit) }
   ]
  return this.aggregate(per).exec()
}

revCollection.statics.queryUsertypeDis = function(){
    var ppe = [];
  ppe=[
      {
        $group : {
           _id : {usertype:"$usertype"},
           count: {$sum:1},        
        }
      }        
   ]
  return this.aggregate(ppe).exec()
}
revCollection.statics.queryAdminUsertypeDis = function(){
    var ppl = [];
    ppl=[
        { $match:{usertype:"admin"} },
        {
            $group : {
                _id : {admintype:"$admintype"},
                count: {$sum:1},
            }
        }
    ]
    return this.aggregate(ppl).exec()
}
revCollection.statics.queryUsertypeDisByYear = function(){
    var lin = [];
    lin =   [
        {
            $group : {
                _id : {year:{$substr:["$timestamp",0,4]}},
                registered: {
                    "$sum":{"$cond": [{ "$eq":[ "$usertype", "registered" ]},1,0] }
                },
                anonymous: {
                    "$sum":{"$cond": [{ "$eq":[ "$usertype", "anonymous" ]},1,0] }
                },
                admin: {
                    "$sum":{"$cond": [{ "$eq":[ "$usertype", "admin" ]},1,0] }
                },
                bot: {
                    "$sum":{"$cond": [{ "$eq":[ "$usertype", "bot" ]},1,0] }}
            }
        },
        {$sort:{"_id":1}}
    ]
  return this.aggregate(lin).exec()
}

revCollection.statics.getAllTitles = function(){
    var article = [];
   article = [
      {
        $group : {
           _id : {title:"$title"}, 
           count:{$sum:1}
        }
      },
      {$sort:{"_id":1}}
   ]
  return this.aggregate(article).exec()
}

revCollection.statics.getArticleTopUsers = function(options){
    var topuser = [];
  topuser = [

      {
          $match:{$and:[{"title":{$eq:options.title}}, {"usertype":{$eq:"registered"}}, {"timestamp":{$gte : options.yearfrom, $lte : options.yearto }}]}
      },
      {
        $group : {
           _id : {user:"$user"}, 
           count:{$sum:1}
        }
      },
       {$sort:{"count":-1}},
       {$limit:5}
   ]
  return this.aggregate(topuser).exec()
}

revCollection.statics.queryExtRev = function(options){
    var pp = [];
    pp = [
        {
            $group : {
                _id : {title:"$title"},
                count: { $sum:1 }
            }
        },
        { $sort:{ count:parseInt(options.sortDirection) } },
        { $limit: parseInt(options.displayLimit) }
    ]
    return this.aggregate(pp).exec()
}


revCollection.statics.queryArticleDisUsertype = function(options){
    var usertype = [];
  usertype =    [
      {
          $match:{$and:[{"title":{$eq:options.title}}, {"timestamp":{$gte : options.yearfrom, $lte : options.yearto }}]}
      },
    {
        $group : {
           _id : {usertype:"$usertype"},
           count: {$sum:1},        
        }
      }        
   ]
  return this.aggregate(usertype).exec()
}

revCollection.statics.queryArticleDisByUser = function(options){
    var disuser = [];
  disuser =    [
       {
           $match:{$and:[{"title":{$eq:options.title}},  {"timestamp":{$gte : options.yearfrom, $lte : options.yearto }}]}
       },
       
      {
        $group : {
           _id : {year:{$substr:["$timestamp",0,4]}},
            user1: {
                "$sum":{"$cond": [{ "$eq":[ "$user", options.user[0] ]},1,0] }
            },
            user2: {
                "$sum":{"$cond": [{ "$eq":[ "$user", options.user[1] ]},1,0] }
            },
            user3: {
                "$sum":{"$cond": [{ "$eq":[ "$user", options.user[2] ]},1,0] }
            },
            user4: {
                "$sum":{"$cond": [{ "$eq":[ "$user", options.user[3] ]},1,0] }
            },
            user5: {
                "$sum":{"$cond": [{ "$eq":[ "$user", options.user[4] ]},1,0] }
            },
          // count:{$sum:1}
        }
      },
       {$sort:{"_id":1}}
   ]
  return this.aggregate(disuser).exec()
}


revCollection.statics.queryArticleDisYear = function(options){
    var disyear = [];
    disyear =   [
        {
            $match:{$and:[{"title":{$eq:options.title}}, {"timestamp":{$gte : options.yearfrom, $lte : options.yearto }}]}
        },
        {

            $group : {
                _id : {year:{$substr:["$timestamp",0,4]}},
                registered: {
                    "$sum":{"$cond": [{ "$eq":[ "$usertype", "registered" ]},1,0] }
                },
                anonymous: {
                    "$sum":{"$cond": [{ "$eq":[ "$usertype", "anonymous" ]},1,0] }
                },
                admin: {
                    "$sum":{"$cond": [{ "$eq":[ "$usertype", "admin" ]},1,0] }
                },
                bot: {
                    "$sum":{"$cond": [{ "$eq":[ "$usertype", "bot" ]},1,0] }}
            }
        },
        {$sort:{"_id":1}}
    ]
    return this.aggregate(disyear).exec()
}
revCollection.statics.getAriticleLastDate = function(title){
    var lastdate = [];
  lastdate =     [
    {$match:{"title":title}},
    {$project:{"date":"$timestamp"}},
    {$sort:{"date":-1}},
    {$limit:1}
]
  return this.aggregate(lastdate).exec()
}
revCollection.statics.findUserType = function(options){
    var username = options.user;
    var userinfo = {"user":username}

    return this.find(userinfo).limit(1).exec()

}
revCollection.statics.findUserAriticle = function(options){

    var article = [];
    article =  [
        { $match:{"user":{$regex:options.user,$options:"$i"}}
        },
        {
            $group : {
                _id : {user:"$user", title:"$title"},
                count:{$sum:1},
                timeStamps:{$addToSet:"$timestamp"}
            }
        },
        {$sort:{"_id":1}}
    ]
    return this.aggregate(article).exec()
}

revCollection.statics.updateArticle = function(title,lastDate, callback){
  var wikurl ="https://en.wikipedia.org/w/api.php";
  var model = this;
  var parameters = ["action=query","format=json","prop=revisions","titles="+querystring.escape(title),"rvstart="+querystring.escape(lastDate.toISOString()),
     "rvdir=newer", "rvprop="+querystring.escape("timestamp|userid|user|ids"),"rvlimit=max"]
  var url = wikurl + "?" + parameters.join("&"); //construct url
  var options = { url:url,method:'POST',
    json:true,Accept: 'application/json',
    headers:{  'Connection': 'keep-alive', 'Api-User-Agent': 'Example/1.0'}
  }

  request(options,function(err, res, data){
    if (err){
      console.log('Error:', err);
    }else if (res.statusCode !==200){
      console.log('Status:', res.statusCode)
    }else if(res.statusCode==200){
      var pages = data.query.pages
      var revisions = pages[Object.keys(pages)[0]].revisions;//get revision objects 
      if(revision){
        var updateArray = [];
        for (var i = 0;i<revisions.length;i++){
          var rev = revisions[i];
          if (rev.timestamp.substring(0,19) == lastDate.toISOString().substring(0,19)){
            continue;
          }
          var new_rev = {'title':title, 'user':rev.user,'userid':rev.userid,'timestamp':rev.timestamp
            }
          updateArray.push(new_rev);
          }
          model.insertMany(updateArray,function(err,result){
          callback(null,updateArray.length)
        })
      }else{
        callback(null,1)
      }
    }    
  })
}
var revision = mongoose.model('Revision', revCollection, 'revisions');
function readText(model){
    var path = "./bot.txt"
    var type = "bot"
    var userArray = [];
    var readline = fs.readFileSync(path).toString().split('\n');
    for (var i=0;i<readline.length;i++){
        userArray.push(readline[i]);
    }


    model.updateMany(
        { $and: [{ user:{$in:userArray}}, {usertype:{$exists:false}}]},
        { $set:{"usertype":type}},
        function(err){
            if(err){
                console.error(err)
            }
        })

    userArray = [];
    path = "./admin_active.txt"
    type = "admin_active"
    var readline = fs.readFileSync(path).toString().split('\n');
    for (var i=0;i<readline.length;i++){
        userArray.push(readline[i]);
    }
    model.updateMany(
        { $and: [{ user:{$in:userArray}}, {usertype:{$exists:false}}]},
        { $set:{"usertype":'admin',"admintype":type}},
        function(err){
            if(err){
                console.error(err)
            }
        }
    )

    userArray = [];
    path = "./admin_former.txt"
    type = "admin_former"
    var readline = fs.readFileSync(path).toString().split('\n');
    for (var i=0;i<readline.length;i++){
        userArray.push(readline[i]);
    }
    model.updateMany(
        { $and: [{ user:{$in:userArray}}, {usertype:{$exists:false}}]},
        { $set:{"usertype":'admin',"admintype":type}},
        function(err){
            if(err){
                console.error(err)
            }
        }
    )

    userArray = [];
    path = "./admin_inactive.txt"
    type = "admin_inactive"
    var readline = fs.readFileSync(path).toString().split('\n');
    for (var i=0;i<readline.length;i++){
        userArray.push(readline[i]);
    }

    model.updateMany(
        { $and: [{ user:{$in:userArray}}, {usertype:{$exists:false}}]},
        { $set:{"usertype":'admin',"admintype":type}},
        function(err){
            if(err){
                console.error(err)
            }
        }
    )

    userArray = [];
    path = "./admin_semi_active.txt"
    type = "admin_semi_active"
    var readline = fs.readFileSync(path).toString().split('\n');
    for (var i=0;i<readline.length;i++){
        userArray.push(readline[i]);
    }
    model.updateMany(
        { $and: [{ user:{$in:userArray}}, {usertype:{$exists:false}}]},
        { $set:{"usertype":'admin',"admintype":type}},
        function(err){
            if(err){
                console.error(err)
            }
        }
    )
}
readText(revision)

revision.updateMany(
    { $and:[{usertype:{$exists:false}},{anon:{$exists:false}}] },
    { $set:{"usertype":"registered"}},
    function(err){
      if(err){
        console.error(err)
      }
    }
  )
revision.updateMany(
    { $and:[{usertype:{$exists:false}},{anon:{$exists:true}}] },
    { $set:{"usertype":"anonymous"}},
    function(err){
      if(err){
        console.error(err)
      }
    }
  )

var userSchema = new mongoose.Schema(
    {
        firstname: {type:String,required:true},
        lastname: { type:String,required:true },
        username:{ type: String,required: true,trim: true},
        emailaddress: { type: String,unique: true,required: true,trim: true},
        password: {type: String,required: true,trim: true}
    },
    {versionKey: false }
);

userSchema.statics.registerUser = function(registerInfo){
    var fname = registerInfo.firstname;
    var lname = registerInfo.lastname;
    var email = registerInfo.emailaddress;
    var username = registerInfo.username;
    var pwd = registerInfo.password;
    var new_user = { 'firstname':fname, 'lastname':lname,'emailaddress':email,
     'username':username, 'password':pwd}
  return this.create(new_user)
}

userSchema.statics.findUser = function(userInput){
    var emailadd = userInput.emailaddress;
    var pwd = userInput.password;
    var userinfo = {'emailaddress':emailadd, 'password':pwd}
  return this.find(userinfo).exec()
}
var user = mongoose.model('User', userSchema, 'users');
module.exports = {revision, user}




