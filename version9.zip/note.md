WikiLatic is a full-stack web application that analyzes revisions on wikipedia articles. Analysis are performed in overall, individual and article level.
written by Kun Zhang (kunzhang1110@gmail.com)
-----------------------------------------------------------------------------------
1. use import_revisions.bat to import revisions(default in root) MongoDB server
2. start the server in shell (can use start_db_server.bat)
3. start the web server in a new shell
		node index.js
4. type localhost://3000 browser's address bar

